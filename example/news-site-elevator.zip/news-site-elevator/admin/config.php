<?php
$hostname = "http://127.0.0.1/news-site-elevator/";


$conn = mysqli_connect("localhost","root","","news-site") or die("Connection failed : " . mysqli_connect_error());

?>
